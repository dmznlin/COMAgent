#if !defined(AFX_USERINPUT_H__C156C89D_EC86_436D_88CF_B0612A4C0CAC__INCLUDED_)
#define AFX_USERINPUT_H__C156C89D_EC86_436D_88CF_B0612A4C0CAC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "NetModuleProtocol.h"
// UserInput.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// UserInput dialog

class UserInput : public CDialog
{
// Construction
public:
	void showInit();
	UserInput(CWnd* pParent = NULL);   // standard constructor
	pNetDeviceConfigS pcfg;
// Dialog Data
	//{{AFX_DATA(UserInput)
	enum { IDD = IDD_DIALOG_USER_INFO };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(UserInput)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(UserInput)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USERINPUT_H__C156C89D_EC86_436D_88CF_B0612A4C0CAC__INCLUDED_)
