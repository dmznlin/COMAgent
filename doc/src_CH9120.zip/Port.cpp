// Port.cpp : implementation file
//

#include "stdafx.h"
#include "netmoduleconfig.h"
#include "Port.h"
#include "NetModuleProtocol.h"
#include "NetModuleConfigDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern CNetModuleConfigDlg *parentDlg;
extern BOOL isChinese;
/////////////////////////////////////////////////////////////////////////////
// CPort dialog


CPort::CPort(CWnd* pParent /*=NULL*/)
	: CDialog(CPort::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPort)
	m_net_mode = 0;
	m_net_port = 0;
	m_dest_port = 0;
	m_domain_name = _T("");
	m_dns_port = 0;
	m_pack_length = 0;
	m_pack_timeout = 0;
	m_retry = 0;
	//}}AFX_DATA_INIT
}


void CPort::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPort)
	DDX_Control(pDX, IDC_IPADDRESS_DNS_IP, m_dns_ip);
	DDX_Control(pDX, IDC_IPADDRESS_DEST_IP, m_dest_ip);
	DDX_Text(pDX, IDC_EDIT_NET_MODE, m_net_mode);
	DDX_Text(pDX, IDC_EDIT_NET_PORT, m_net_port);
	DDX_Text(pDX, IDC_EDIT_DEST_PORT, m_dest_port);
	DDX_Text(pDX, IDC_EDIT_DNS_NAME, m_domain_name);
	DDX_Text(pDX, IDC_EDIT_DNS_PORT, m_dns_port);
	DDX_Text(pDX, IDC_EDIT_PACK_LENGTH, m_pack_length);
	DDX_Text(pDX, IDC_EDIT_PACK_TIMEOUT, m_pack_timeout);
	DDX_Text(pDX, IDC_EDIT_RETRY_TIME, m_retry);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPort, CDialog)
	//{{AFX_MSG_MAP(CPort)
	ON_BN_CLICKED(IDC_STATIC_1, OnStatic1)
	ON_BN_CLICKED(IDC_STATIC_2, OnStatic2)
	ON_BN_CLICKED(IDC_STATIC_3, OnStatic3)
	ON_BN_CLICKED(IDC_STATIC_4, OnStatic4)
	ON_BN_CLICKED(IDC_STATIC_5, OnStatic5)
	ON_BN_CLICKED(IDC_STATIC_6, OnStatic6)
	ON_BN_CLICKED(IDC_STATIC_7, OnStatic7)
	ON_BN_CLICKED(IDC_STATIC_8, OnStatic8)
	ON_BN_CLICKED(IDC_STATIC_9, OnStatic9)
	ON_BN_CLICKED(IDC_STATIC_10, OnStatic10)
	ON_BN_CLICKED(IDC_STATIC_11, OnStatic11)
	ON_BN_CLICKED(IDC_STATIC_12, OnStatic12)
	ON_BN_CLICKED(IDC_STATIC_13, OnStatic13)
	ON_BN_CLICKED(IDC_STATIC_14, OnStatic14)
	ON_BN_CLICKED(IDC_STATIC_15, OnStatic15)
	ON_BN_CLICKED(IDC_STATIC_16, OnStatic16)
	ON_BN_CLICKED(IDC_STATIC_17, OnStatic17)
	ON_BN_CLICKED(IDC_STATIC_18, OnStatic18)
	ON_BN_CLICKED(IDC_CHECK_PORT_RANDOM, OnCheckPortRandom)
	ON_WM_CANCELMODE()
	ON_CBN_SELCHANGE(IDC_COMBO_CONNECT_TYPE,OnSelchangeComboNetChange)
	ON_BN_CLICKED(IDC_STATIC_19, OnStatic19)
	ON_BN_CLICKED(IDC_BTN_PORT_SET, OnBtnPortSet)
	ON_CBN_SELCHANGE(IDC_COMBO_NET_MODE, OnSelchangeComboNetMode)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPort message handlers

void CPort::ShowPort(pNetDeviceConfigS pcfg)
{
	//����ģʽ
	char   str[30]="";
	m_net_mode=pcfg->PortCfg[NUM].bNetMode;
	((CComboBox*)GetDlgItem(IDC_COMBO_NET_MODE))->SetCurSel
		(pcfg->PortCfg[NUM].bNetMode);
	//�����TCPSERVERģʽʱ��������˵㣬���ӷ�ʽ�Լ�IP���˵����
	if(pcfg->PortCfg[NUM].bNetMode==0)
	{
		(GetDlgItem(IDC_CHECK_PORT_RANDOM))->EnableWindow(FALSE);
		(GetDlgItem(IDC_COMBO_CONNECT_TYPE))->EnableWindow(FALSE);
		(GetDlgItem(IDC_IPADDRESS_DEST_IP))->EnableWindow(FALSE);
		(GetDlgItem(IDC_EDIT_DEST_PORT))->EnableWindow(FALSE);
	}
	else
	{
		(GetDlgItem(IDC_CHECK_PORT_RANDOM))->EnableWindow(TRUE);
		(GetDlgItem(IDC_COMBO_CONNECT_TYPE))->EnableWindow(TRUE);
		(GetDlgItem(IDC_IPADDRESS_DEST_IP))->EnableWindow(TRUE);
		(GetDlgItem(IDC_EDIT_DEST_PORT))->EnableWindow(TRUE);
	}
	if(NUM==0)
	{
		(GetDlgItem(IDC_COMBO_CONNECT_TYPE))->EnableWindow(FALSE);
	}
	//�˿��Ƿ����
	((CButton*)GetDlgItem(IDC_CHECK_PORT_RANDOM))->SetCheck
		(pcfg->PortCfg[NUM].bRandSportFlag);
	((CButton*)GetDlgItem(IDC_EDIT_NET_PORT))->EnableWindow
		(pcfg->PortCfg[NUM].bRandSportFlag!=0? FALSE:TRUE);
	//����˿�
	m_net_port=pcfg->PortCfg[NUM].wNetPort;
	//Ŀ�ĵ�ַIP
	m_dest_ip.SetAddress(pcfg->PortCfg[NUM].bDesIP[0],pcfg->PortCfg[NUM].bDesIP[1],
		pcfg->PortCfg[NUM].bDesIP[2],pcfg->PortCfg[NUM].bDesIP[3]);
	//Ŀ�Ķ˿�
	m_dest_port=pcfg->PortCfg[NUM].wDesPort;
	sprintf(str,"%d",pcfg->PortCfg[NUM].dBaudRate);
	GetDlgItem(IDC_COMBO_SERIAL_BAUD)->SetWindowText(str);
	//����λ
	((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_DATA_BIT))->SetCurSel
		(pcfg->PortCfg[NUM].bDataSize-5);
	//ֹͣλ
	((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_STOP_BIT))->SetCurSel
		(pcfg->PortCfg[NUM].bStopBits-1);
	//��żУ��
	((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_PARITY))->SetCurSel
		(pcfg->PortCfg[NUM].bParity);
	//�����Ͽ�ʱ,�Ƿ�ر�SOCKET
	((CButton*)GetDlgItem(IDC_CHECK_PHY))->SetCheck(pcfg->PortCfg[NUM].bPHYChangeHandle);
	//�������ӣ��Ƿ�������ڻ�����
	((CButton*)GetDlgItem(IDC_CHECK_CLR_RTS))->SetCheck(pcfg->PortCfg[NUM].bResetCtrl);
	//�������
	m_pack_length=pcfg->PortCfg[NUM].dRxPktlength;
	//�����ʱ
	m_pack_timeout=pcfg->PortCfg[NUM].dRxPktTimeout;
	//����CLIENT����
	m_retry=pcfg->PortCfg[NUM].bReConnectCnt;
	//�������DNS�Ļ���DNS�ؼ�combox����Ϊ��Ӧ��ֵ
	if(pcfg->PortCfg[NUM].bDNSFlag==0)
	{
		((CComboBox*)GetDlgItem(IDC_COMBO_CONNECT_TYPE))->SetCurSel(0);
	}
	else
	{
		((CComboBox*)GetDlgItem(IDC_COMBO_CONNECT_TYPE))->SetCurSel(1);
	}
	//DNS
	m_domain_name=(char*)pcfg->PortCfg[NUM].szDomainname;
	//�ж����ӷ�ʽΪĿ�껹��Ip��ַ

	if(pcfg->PortCfg[NUM].bDNSFlag!=0)
	{
		
		GetDlgItem(IDC_STATIC_DNS1)->ShowWindow(TRUE);
		GetDlgItem(IDC_STATIC_DNS2)->ShowWindow(TRUE);
		GetDlgItem(IDC_STATIC15)->ShowWindow(TRUE);
		GetDlgItem(IDC_STATIC16)->ShowWindow(TRUE);
		GetDlgItem(IDC_CHECK_ENABLE_DNS)->ShowWindow(TRUE);
		GetDlgItem(IDC_EDIT_DNS_NAME)->ShowWindow(TRUE);
		
		GetDlgItem(IDC_STATIC_IP1)->ShowWindow(FALSE);
		GetDlgItem(IDC_IPADDRESS_DEST_IP)->ShowWindow(FALSE);
	//	GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(FALSE);
	//	GetDlgItem(IDC_EDIT_DEST_PORT)->ShowWindow(FALSE);
		GetDlgItem(IDC_STATIC_4)->ShowWindow(FALSE);
	
	}
	else
	{
		GetDlgItem(IDC_STATIC_DNS1)->ShowWindow(FALSE);
		GetDlgItem(IDC_STATIC_DNS2)->ShowWindow(FALSE);
		GetDlgItem(IDC_STATIC15)->ShowWindow(FALSE);
		GetDlgItem(IDC_STATIC16)->ShowWindow(FALSE);
		GetDlgItem(IDC_CHECK_ENABLE_DNS)->ShowWindow(FALSE);
		GetDlgItem(IDC_EDIT_DNS_NAME)->ShowWindow(FALSE);
		
		GetDlgItem(IDC_STATIC_IP1)->ShowWindow(TRUE);
		GetDlgItem(IDC_IPADDRESS_DEST_IP)->ShowWindow(TRUE);
		GetDlgItem(IDC_STATIC_4)->ShowWindow(TRUE);
	}
}

void CPort::getPort(pNetDeviceConfigS pcfg)
{
	UpdateData(TRUE);
	//�˶˿�Ϊ�ĸ��˿�
	pcfg->PortCfg[NUM].bIndex=NUM;
	//����ģʽ
	pcfg->PortCfg[NUM].bNetMode=((CComboBox*)GetDlgItem(IDC_COMBO_NET_MODE))->GetCurSel();
	//���ض˿��Ƿ����
	pcfg->PortCfg[NUM].bRandSportFlag=((CButton*)GetDlgItem(IDC_CHECK_PORT_RANDOM))->GetCheck();
	//��������˿ں�
	pcfg->PortCfg[NUM].wNetPort=m_net_port;
	//���ӷ�ʽ��IP����������ʽ
	if(((CComboBox*)GetDlgItem(IDC_COMBO_CONNECT_TYPE))->GetCurSel()==0)
	{
		//Ŀ��IP
		m_dest_ip.GetAddress(pcfg->PortCfg[NUM].bDesIP[0],pcfg->PortCfg[NUM].bDesIP[1],
		pcfg->PortCfg[NUM].bDesIP[2],pcfg->PortCfg[NUM].bDesIP[3]);
		//Ŀ�ĵĶ˿ڵ�ַ
		pcfg->PortCfg[NUM].wDesPort=m_dest_port;
	}
	else
	{
		//Ŀ�ĵĶ˿ڵ�ַ
		pcfg->PortCfg[NUM].wDesPort=m_dest_port;
	}
	
	pcfg->PortCfg[NUM].dBaudRate=GetDlgItemInt(IDC_COMBO_SERIAL_BAUD,NULL,TRUE);
	if((pcfg->PortCfg[NUM].dBaudRate)<300)
	{
		AfxMessageBox(isChinese?"�����ʱ������300!":"Baud must be greater than 300!");
		return;
	}
/*	
	UINT baud;
	baud=((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_BAUD))->GetCurSel();
	switch(baud)
	{
	case 0:
		pcfg->PortCfg[NUM].dBaudRate=300;
		break;
	case 1:
		pcfg->PortCfg[NUM].dBaudRate=600;
		break;
	case 2:
		pcfg->PortCfg[NUM].dBaudRate=1200;
		break;
	case 3:
		pcfg->PortCfg[NUM].dBaudRate=2400;
		break;
	case 4:
		pcfg->PortCfg[NUM].dBaudRate=4800;
		break;
	case 5:
		pcfg->PortCfg[NUM].dBaudRate=9600;
		break;
	case 6:
		pcfg->PortCfg[NUM].dBaudRate=14400;
		break;
	case 7:
		pcfg->PortCfg[NUM].dBaudRate=19200;
		break;
	case 8:
		pcfg->PortCfg[NUM].dBaudRate=38400;
		break;
	case 9:
		pcfg->PortCfg[NUM].dBaudRate=57600;
		break;
	case 10:
		pcfg->PortCfg[NUM].dBaudRate=115200;
		break;
	case 11:
		pcfg->PortCfg[NUM].dBaudRate=230400;
		break;
	case 12:
		pcfg->PortCfg[NUM].dBaudRate=460800;
		break;
	case 13:
		pcfg->PortCfg[NUM].dBaudRate=921600;
		break;
		}   */
	//�˿ڴ�������Ϊ
	pcfg->PortCfg[NUM].bDataSize=((CComboBox*)
		(GetDlgItem(IDC_COMBO_SERIAL_DATA_BIT)))->GetCurSel()+5;
	//�˿ڴ���ֹͣλ
	pcfg->PortCfg[NUM].bStopBits=(UCHAR)((CComboBox*)
		(GetDlgItem(IDC_COMBO_SERIAL_STOP_BIT)))->GetCurSel()+1;
	//�˿ڴ�����żУ��λ
	pcfg->PortCfg[NUM].bParity=(UCHAR)((CComboBox*)
		(GetDlgItem(IDC_COMBO_SERIAL_PARITY)))->GetCurSel();
	//��PHY�Ͽ�ʱ�ǹر�SOCKET
	pcfg->PortCfg[NUM].bPHYChangeHandle=((CButton*)
		GetDlgItem(IDC_CHECK_PHY))->GetCheck();
	//���ڴ������
	pcfg->PortCfg[NUM].dRxPktlength=m_pack_length;

	if(pcfg->PortCfg[NUM].dRxPktlength > 512)
	{
		AfxMessageBox(isChinese?"RX������ȱ���С��512!":"RX packaging length must be less than 512!");
		return;
	}
	//���ڴ����ʱ
	pcfg->PortCfg[NUM].dRxPktTimeout=m_pack_timeout;
	//����������ʱ���Ƿ�������ڻ�����
	pcfg->PortCfg[NUM].bResetCtrl=((CButton*)GetDlgItem(IDC_CHECK_CLR_RTS))->GetCheck();
	//����Ŀ�����Ƿ����DNS�����ӷ�ʽ
	pcfg->PortCfg[NUM].bDNSFlag=(((CComboBox*)GetDlgItem(IDC_COMBO_CONNECT_TYPE))->
		GetCurSel()==1)?TRUE:FALSE;
	//Ŀ�ĵ�������ַ
	strcpy((char*)pcfg->PortCfg[NUM].szDomainname,m_domain_name);
	//TCP CLIENTʱ��������ʱ���ԵĴ���
	pcfg->PortCfg[NUM].bReConnectCnt=m_retry;

}

//IP�Լ��������ӵķ�ʽ
void CPort::OnSelchangeComboNetChange()
{
	UINT index;
	index=((CComboBox*)GetDlgItem(IDC_COMBO_CONNECT_TYPE))->GetCurSel();
	if(NUM==1)//����Ƕ˿�1
	{
		if(index==1)
		{
			GetDlgItem(IDC_STATIC_DNS1)->ShowWindow(TRUE);
			GetDlgItem(IDC_STATIC_DNS2)->ShowWindow(TRUE);
			GetDlgItem(IDC_STATIC15)->ShowWindow(TRUE);
			GetDlgItem(IDC_STATIC16)->ShowWindow(TRUE);
			GetDlgItem(IDC_CHECK_ENABLE_DNS)->ShowWindow(TRUE);
			GetDlgItem(IDC_EDIT_DNS_NAME)->ShowWindow(TRUE);
		//	GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(FALSE);
			GetDlgItem(IDC_STATIC_IP1)->ShowWindow(FALSE);
			GetDlgItem(IDC_IPADDRESS_DEST_IP)->ShowWindow(FALSE);
			GetDlgItem(IDC_STATIC_4)->ShowWindow(FALSE);
		}
		else
		{
			GetDlgItem(IDC_STATIC_DNS1)->ShowWindow(FALSE);
			GetDlgItem(IDC_STATIC_DNS2)->ShowWindow(FALSE);
			GetDlgItem(IDC_STATIC15)->ShowWindow(FALSE);
			GetDlgItem(IDC_STATIC16)->ShowWindow(FALSE);
			GetDlgItem(IDC_CHECK_ENABLE_DNS)->ShowWindow(FALSE);
			GetDlgItem(IDC_EDIT_DNS_NAME)->ShowWindow(FALSE);
		//	GetDlgItem(IDC_EDIT_DEST_PORT)->EnableWindow(TRUE);
			
			GetDlgItem(IDC_STATIC_IP1)->ShowWindow(TRUE);
			GetDlgItem(IDC_IPADDRESS_DEST_IP)->ShowWindow(TRUE);
			GetDlgItem(IDC_STATIC_4)->ShowWindow(TRUE);
	
		}	
	}//����Ƕ˿�2,�򲻲���
	else
	{
		
	}

}

void CPort::OnStatic1() 
{
	AfxMessageBox(_T("�ö˿��Ƿ�����"));
}

void CPort::OnStatic2() 
{
	if(isChinese)
		AfxMessageBox(_T("�˿�����ģʽ"));
	else
		AfxMessageBox(_T("Port Net Type"));
}

void CPort::OnStatic3() 
{
	if(isChinese)
		AfxMessageBox(_T("TCP �ͻ���ģʽ���漴���ض˿ںţ�1����� 0: �����"));
	else
		AfxMessageBox(_T("TCP Client Mode,local port,1:Random 0:Fixed"));
}

void CPort::OnStatic4() 
{
	if(isChinese)
		AfxMessageBox(_T("Ŀ��IP��ַ"));
	else
		AfxMessageBox(_T("Destionation Ip"));
}

void CPort::OnStatic5() 
{
	if(isChinese)
		AfxMessageBox(_T("Ŀ���豸�Ķ˿ں�"));
	else
		AfxMessageBox(_T("Target Device Port"));
	
}

void CPort::OnStatic6() 
{
	if(isChinese)
		AfxMessageBox(_T("���ڲ�����: >300bps"));
	else
		AfxMessageBox(_T("Serial Port Baud: >300bps"));
}

void CPort::OnStatic7() 
{
	if(isChinese)
		AfxMessageBox(_T("��������λ: 5---8λ"));
	else
		AfxMessageBox(_T("Serial Data Bit: 5---8"));
}

void CPort::OnStatic8() 
{
	if(isChinese)
		AfxMessageBox(_T("����ֹͣλ: 0��ʾ1��ֹͣλ; 1��ʾ1.5��ֹͣλ; 2��ʾ2��ֹͣλ"));
	else
		AfxMessageBox(_T("Serial Stop Bit: 0 means One Stop Bit; 1 means 1.5 Stop Bit; 2 means 2 Stop Bit"));
}

void CPort::OnStatic9() 
{
	if(isChinese)
		AfxMessageBox(_T("����У��λ: 0��ʾ��У��; 1��ʾżУ��; 2��ʾ��־λ(MARK,��1); 3��ʾ�հ�λ(SPACE,��0)"));
	else
		AfxMessageBox(_T("Serial Parity: 0 means ODD; 1 means Even; 2 means MARK; 3 means SPACE"));
}

void CPort::OnStatic10() 
{
	if(isChinese)
		AfxMessageBox(_T("���������Ͽ�ʱ��1��ʾģ��ر�����Socket,0��ʾģ�鲻����"));
	else
		AfxMessageBox(_T("When Connection is cut, 1 means Socket closes,0 means doing nothing"));

}

void CPort::OnStatic11() 
{
	if(isChinese)
		AfxMessageBox(_T("����RX��������������ת��ʱ�Ĵ�����ȣ����1024"));
	else
		AfxMessageBox(_T("Serial RX to Network Pack Length, 1024 maximum"));
}

void CPort::OnStatic12() 
{
	if(isChinese)
		AfxMessageBox(_T("����RX���ݴ��ת�������ȴ�ʱ��,��λΪ: 10ms,0���ʾ�رճ�ʱ����"));
	else
		AfxMessageBox(_T("Serial RX to Network Pack maximum waiting time, uint: 10ms,0 means turning off this function"));
}

void CPort::OnStatic13() 
{
	AfxMessageBox(_T("������TCP CLIENTʱ������TCP SERVER��������Դ���"));
}

void CPort::OnStatic14() 
{
	if(isChinese)
		AfxMessageBox(_T("���ڸ�λ����: 0��ʾ����մ������ݻ�����; 1��ʾ����ʱ��մ������ݻ�����"));
	else
		AfxMessageBox(_T("Serial Reset Function: 0 means not clearing serial buffer; 1 means clearing serial buffer when socket connects"));
}

void CPort::OnStatic15() 
{
	AfxMessageBox(_T("�����������ñ�־��1������ 2��������"));
}

void CPort::OnStatic16() 
{
	AfxMessageBox(_T("����"));
}

void CPort::OnStatic17() 
{
	AfxMessageBox(_T("DNS ����"));
}

void CPort::OnStatic18() 
{
	AfxMessageBox(_T("DNS �˿�"));
}


void CPort::OnStatic19() 
{
	if(isChinese)
		AfxMessageBox(_T("ͨ��IP��������ȥ�����豸"));
	else
		AfxMessageBox(_T("Connect Target by IP or domain"));
}

//���ض˿��Ƿ����
void CPort::OnCheckPortRandom() 
{
	if(((CButton*)GetDlgItem(IDC_CHECK_PORT_RANDOM))->GetCheck()==TRUE)
	{
		((CButton*)GetDlgItem(IDC_EDIT_NET_PORT))->EnableWindow(FALSE);
	}
	else
	{
		((CButton*)GetDlgItem(IDC_EDIT_NET_PORT))->EnableWindow(TRUE);
	}
}

BOOL CPort::OnInitDialog() 
{
	CDialog::OnInitDialog();
 	GetDlgItem(IDC_STATIC_DNS1)->ShowWindow(FALSE);
	GetDlgItem(IDC_STATIC_DNS2)->ShowWindow(FALSE);
	GetDlgItem(IDC_STATIC15)->ShowWindow(FALSE);
	GetDlgItem(IDC_STATIC16)->ShowWindow(FALSE);
	GetDlgItem(IDC_CHECK_ENABLE_DNS)->ShowWindow(FALSE);
	GetDlgItem(IDC_EDIT_DNS_NAME)->ShowWindow(FALSE);


	GetDlgItem(IDC_STATIC_IP1)->ShowWindow(TRUE);
	GetDlgItem(IDC_STATIC_IP2)->ShowWindow(TRUE);
	GetDlgItem(IDC_IPADDRESS_DEST_IP)->ShowWindow(TRUE);
	GetDlgItem(IDC_EDIT_DEST_PORT)->ShowWindow(TRUE);
	GetDlgItem(IDC_STATIC4)->ShowWindow(TRUE);
	GetDlgItem(IDC_STATIC5)->ShowWindow(TRUE);

	if(!isChinese)
	{
		GetDlgItem(IDC_STATIC_MODE)->SetWindowText("Mode:");
		GetDlgItem(IDC_STATIC_SPORT)->SetWindowText("Local Port:");
		GetDlgItem(IDC_STATIC_DEST)->SetWindowText("Conn Type:");
		GetDlgItem(IDC_STATIC_IP1)->SetWindowText("Dest IP:");
		GetDlgItem(IDC_STATIC_IP2)->SetWindowText("Dest Port:");
		GetDlgItem(IDC_STATIC_BAUD)->SetWindowText("Baud:");
		GetDlgItem(IDC_STATIC_DATA_BIT)->SetWindowText("Data Bit:");
		GetDlgItem(IDC_STATIC_STOP_BIT)->SetWindowText("Stop Bit:");
		GetDlgItem(IDC_STATIC_PARITY)->SetWindowText("Parity:");
		GetDlgItem(IDC_STATIC_WIRE_LOST)->SetWindowText("Conn Lost:");
		GetDlgItem(IDC_STATIC_PACK_LENGTH)->SetWindowText("Pack Len:");
		GetDlgItem(IDC_STATIC_PACK_TIMEOUT)->SetWindowText("Pack TimeOut:");
		GetDlgItem(IDC_STATIC_CLR_RX)->SetWindowText("Reconnect:");

		GetDlgItem(IDC_CHECK_PORT_RANDOM)->SetWindowText("Random:");
		GetDlgItem(IDC_CHECK_PHY)->SetWindowText("Close Conn");
		GetDlgItem(IDC_CHECK_CLR_RTS)->SetWindowText("Clear Buff");
		GetDlgItem(IDC_STATIC_DNS2)->SetWindowText("DNS:");
		GetDlgItem(IDC_BTN_PORT_SET)->SetWindowText("Set Port");
		
	}

	if(isChinese)
	{
		((CComboBox*)GetDlgItem(IDC_COMBO_CONNECT_TYPE))->AddString("IP");
		((CComboBox*)GetDlgItem(IDC_COMBO_CONNECT_TYPE))->AddString("����");

			/*��У��
			żУ��
			MarkУ��
			SpaceУ��
			��У��*/
		((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_PARITY))->AddString("��У��");
		((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_PARITY))->AddString("żУ��");
		((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_PARITY))->AddString("MarkУ��");
		((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_PARITY))->AddString("SpaceУ��");
		((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_PARITY))->AddString("��У��");
	}
	else
	{
		((CComboBox*)GetDlgItem(IDC_COMBO_CONNECT_TYPE))->AddString("IP");
		((CComboBox*)GetDlgItem(IDC_COMBO_CONNECT_TYPE))->AddString("Domain");

		((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_PARITY))->AddString("Odd");
		((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_PARITY))->AddString("Even");
		((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_PARITY))->AddString("Mark");
		((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_PARITY))->AddString("Space");
		((CComboBox*)GetDlgItem(IDC_COMBO_SERIAL_PARITY))->AddString("None");
	}
	((CComboBox*)GetDlgItem(IDC_COMBO_CONNECT_TYPE))->SetCurSel(0);
	((CComboBox*)GetDlgItem(IDC_COMBO_NET_MODE))->SetCurSel(0);

	//Ĭ�ϲ���TCPSERVERģʽ�����Խ����õĿؼ�����
	(GetDlgItem(IDC_CHECK_PORT_RANDOM))->EnableWindow(FALSE);
	(GetDlgItem(IDC_COMBO_CONNECT_TYPE))->EnableWindow(FALSE);
	(GetDlgItem(IDC_IPADDRESS_DEST_IP))->EnableWindow(FALSE);
	(GetDlgItem(IDC_EDIT_DEST_PORT))->EnableWindow(FALSE);
	return TRUE;  
}

void CPort::OnCancelMode() 
{
	CDialog::OnCancelMode();
}

//�˿���������
void CPort::OnBtnPortSet() 
{
	parentDlg->PostMessage(WM_PORT_SET,NUM,0);
}

void CPort::OnSelchangeComboNetMode() 
{
	// TODO: Add your control notification handler code here
	UINT index;
	index=((CComboBox*)GetDlgItem(IDC_COMBO_NET_MODE))->GetCurSel();
	if(index==0)
	{
		(GetDlgItem(IDC_CHECK_PORT_RANDOM))->EnableWindow(FALSE);
		(GetDlgItem(IDC_COMBO_CONNECT_TYPE))->EnableWindow(FALSE);
		(GetDlgItem(IDC_IPADDRESS_DEST_IP))->EnableWindow(FALSE);
	//	(GetDlgItem(IDC_EDIT_DEST_PORT))->EnableWindow(FALSE);
		(GetDlgItem(IDC_EDIT_NET_PORT))->EnableWindow(TRUE);
		((CButton*)(GetDlgItem(IDC_CHECK_PORT_RANDOM)))->SetCheck(FALSE);
	}
	else
	{
		(GetDlgItem(IDC_CHECK_PORT_RANDOM))->EnableWindow(TRUE);
		(GetDlgItem(IDC_COMBO_CONNECT_TYPE))->EnableWindow(TRUE);
		(GetDlgItem(IDC_IPADDRESS_DEST_IP))->EnableWindow(TRUE);
		(GetDlgItem(IDC_EDIT_DEST_PORT))->EnableWindow(TRUE);
	}
}
