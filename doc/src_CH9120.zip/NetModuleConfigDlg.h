// NetModuleConfigDlg.h : header file
//

#if !defined(AFX_NETMODULECONFIGDLG_H__5FF19D5A_C9C3_4868_9054_378C74457065__INCLUDED_)
#define AFX_NETMODULECONFIGDLG_H__5FF19D5A_C9C3_4868_9054_378C74457065__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//ģ��Ĭ���������
#define DEFAULT_MODULE_NAME	"NET MODULE"							//Ĭ��ģ����
#define DEFAULT_WORK_TYPE	NET_MODULE_TYPE_UDP_C					//Ĭ�Ϲ���ģʽ
#define DEFAULT_MODULE_IP	"192.168.1.1"							//Ĭ��ģ��IP
#define DEFAULT_MASK		"255.255.255.0"							//Ĭ����������
#define DEFAULT_GETWAY		"192.168.1.2"							//Ĭ������
#define DEFAULT_MODULE_PROT	1124									//Ĭ��ģ��˿�
#define DEFAULT_DEST_IP		"192.168.1.3"							//Ĭ��Ŀ��IP
#define DEFAULT_DEST_PROT	1124									//Ĭ��Ŀ�Ķ˿�
//ģ��Ĭ�ϴ��ڲ���
#define DEFAULT_BOUND		"115200"								//Ĭ�ϲ�����
#define DEFAULT_TIMEOUT		20										//Ĭ�ϳ�ʱ
#define DEFAULT_DATA_BIT	0										//Ĭ������λ
#define DEFAULT_STOP_BIT	0										//Ĭ��ֹͣλ
#define DEFAULT_VERIFY_BIT	NET_MODULE_VERIFY_NULL					//Ĭ��У��λ
#define MODULE_CONFIG_FILE "config.ini\0"							//�����ļ���			

/////////////////////////////////////////////////////////////////////////////
#include "NetModuleProtocol.h"
#include "TabSheet.h"
#include "Port.h"
#define WM_USER_OLD WM_USER+1
#define WM_PORT_SET WM_USER+2
#define WM_REFRESH WM_USER+3

class CNetModuleConfigDlg : public CDialog
{
// Construction
public:
	CNetModuleConfigDlg(CWnd* pParent = NULL);	// standard constructor
	~CNetModuleConfigDlg();
public:
	void get_mac(int item);								//���豸�б��е�MAC��һ���л�ȡMAC��ַ
	int open_socket();									//����SOCKET
	void log_msg(char* lpformat,...);					//��ʾ��ǰ����״̬���Ƿ�ɹ�
	int get_adapter(int index,BOOL init);				//��ȡ������
	pNetDeviceConfigS pcfg;
	pmodule_cfg pcfg_old;
	void showPort(UINT NUM);
	CPort *port[4];
// Dialog Data
	//{{AFX_DATA(CNetModuleConfigDlg)
	enum { IDD = IDD_NMCFG };
	CTabSheet	m_port_tab_two;
	CTabSheet	m_port_tab;
	CIPAddressCtrl	m_gateway;
	CIPAddressCtrl	m_mask_new;
	CIPAddressCtrl	m_ip;
	CListCtrl		m_mlist;
	UINT	m_soft_ver;
	UINT	m_sn;
	CString	m_modul_name;
	UINT	m_type;
	UINT	m_child_type;
	UINT	m_hard_ver;
	UINT	m_web_port;
	CString	m_user;
	CString	m_password;
	//}}AFX_DATA
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetModuleConfigDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
public:
	void getConfig();
	void showConfig();
	void set_cmd(UINT order);	
	BOOL isPort2Enabled;							//port2�Ƿ�����
	BOOL isOld;										//�����Ǿɰ滹���°�Ĺ̼�
	afx_msg void OnSearch();
// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CNetModuleConfigDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSaveConfig();
//	afx_msg void OnSearch();
	afx_msg void OnResetAll();
	afx_msg void OnConfig();
	afx_msg void OnSelchangeNowadapter();
	afx_msg void OnButtonRefreshadapter();
	afx_msg void OnLoadConfig();
	afx_msg void OnClickModuleList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnStatic1();
	afx_msg void OnStatic2();
	afx_msg void OnStatic3();
	afx_msg void OnStatic4();
	afx_msg void OnStatic5();
	afx_msg void OnStatic6();
	afx_msg void OnStatic7();
	afx_msg void OnStatic8();
	afx_msg void OnStatic9();
	afx_msg void OnStatic10();
	afx_msg void OnStatic11();
	afx_msg void OnStatic12();
	afx_msg void OnStatic13();
	afx_msg void OnStatic14();
	afx_msg void OnStatic15();
	afx_msg void OnStatic16();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnCheckShowPort2();
	afx_msg void OnCheckDhcp();
	afx_msg void OnCheckEnableUser();
	afx_msg void OnStatic17();
	afx_msg LRESULT OnSearchOld(WPARAM wParam,LPARAM lParam);
	afx_msg LRESULT OnPortSet(WPARAM wParam,LPARAM lParam);
	afx_msg LRESULT OnRefresh(WPARAM wParam,LPARAM lParam);
	afx_msg void OnBtnBaseSet();
	afx_msg void OnDblclkModuleList(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETMODULECONFIGDLG_H__5FF19D5A_C9C3_4868_9054_378C74457065__INCLUDED_)
