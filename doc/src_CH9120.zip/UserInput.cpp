// UserInput.cpp : implementation file
//

#include "stdafx.h"
#include "netmoduleconfig.h"
#include "UserInput.h"
#include "NetModuleProtocol.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern BOOL isChinese;
/////////////////////////////////////////////////////////////////////////////
// UserInput dialog

UCHAR g_user_name[8],g_user_password[8];
UserInput::UserInput(CWnd* pParent /*=NULL*/)
	: CDialog(UserInput::IDD, pParent)
{
	//{{AFX_DATA_INIT(UserInput)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void UserInput::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(UserInput)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(UserInput, CDialog)
	//{{AFX_MSG_MAP(UserInput)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// UserInput message handlers

void UserInput::showInit()
{
	GetDlgItem(IDC_EDIT_USER)->SetWindowText((CHAR*)pcfg->HWCfg.szUsername);
	GetDlgItem(IDC_EDIT_PASSWORD)->SetWindowText((CHAR*)pcfg->HWCfg.szPassWord);
}

void UserInput::OnOK() 
{
	// TODO: Add extra validation here
	GetDlgItem(IDC_EDIT_USER)->GetWindowText((CHAR*)g_user_name,8);
	GetDlgItem(IDC_EDIT_PASSWORD)->GetWindowText((CHAR*)g_user_password,8);
	CDialog::OnOK();
}

BOOL UserInput::OnInitDialog() 
{
	CDialog::OnInitDialog();
	showInit();
	// TODO: Add extra initialization here
	if(!isChinese)
	{
		SetWindowText("User Info Input");
		GetDlgItem(IDC_STATIC_USER)->SetWindowText("Name:");
		GetDlgItem(IDC_STATIC_PASSWORD)->SetWindowText("Password:");
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
