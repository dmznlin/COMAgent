#if !defined(AFX_PORT_H__0E96156D_FBC9_4D4A_8B2F_0A6B750BD513__INCLUDED_)
#define AFX_PORT_H__0E96156D_FBC9_4D4A_8B2F_0A6B750BD513__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "NetModuleProtocol.h"
// Port.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPort dialog

class CPort : public CDialog
{
// Construction
public:
	void getPort(pNetDeviceConfigS pcfg);
	UINT NUM;
	void ShowPort(pNetDeviceConfigS pcfg);
	CPort(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPort)
	enum { IDD = IDD_PORT1_DIALOG };
	CIPAddressCtrl	m_dns_ip;
	CIPAddressCtrl	m_dest_ip;
	UINT	m_net_mode;
	UINT	m_net_port;
	UINT	m_dest_port;
	CString	m_domain_name;
	UINT	m_dns_port;
	UINT	m_pack_length;
	UINT	m_pack_timeout;
	UINT	m_retry;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPort)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPort)
	afx_msg void OnStatic1();
	afx_msg void OnStatic2();
	afx_msg void OnStatic3();
	afx_msg void OnStatic4();
	afx_msg void OnStatic5();
	afx_msg void OnStatic6();
	afx_msg void OnStatic7();
	afx_msg void OnStatic8();
	afx_msg void OnStatic9();
	afx_msg void OnStatic10();
	afx_msg void OnStatic11();
	afx_msg void OnStatic12();
	afx_msg void OnStatic13();
	afx_msg void OnStatic14();
	afx_msg void OnStatic15();
	afx_msg void OnStatic16();
	afx_msg void OnStatic17();
	afx_msg void OnStatic18();
	afx_msg void OnCheckPortRandom();
	virtual BOOL OnInitDialog();
	afx_msg void OnCancelMode();
	afx_msg void OnSelchangeComboNetChange();
	afx_msg void OnStatic19();
	afx_msg void OnBtnPortSet();
	afx_msg void OnSelchangeComboNetMode();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PORT_H__0E96156D_FBC9_4D4A_8B2F_0A6B750BD513__INCLUDED_)
